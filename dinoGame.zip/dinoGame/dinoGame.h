/* dinoGame.h
   Header file for Dinosaur Game written by Isac Ljungberg and Brian Onoszko
   Some parts are original code written by Axel Isaksson

   Latest update 2023-03-02 by Isac Ljungberg and Brian Onoszko

   For copyright and licensing, see file COPYING 
*/

/* Declares functions */
void display_image(int x, const uint8_t *data);
void display_init(void);
uint8_t spi_send_recv(uint8_t data);
void run(void);
void quicksleep(int cyc);
void enable_interrupt(void);
int getbtns(void);


/* Declares variables and arrays */
extern uint8_t* icon[4];
extern uint8_t icon0[128];
extern uint8_t icon1[128];
extern uint8_t icon2[128];
extern uint8_t icon3[128];
extern int dinoX;
extern int dinoY;
extern int dinoSizeX;
extern int dinoSizeY;
extern int obsX[8];
extern int obsY[8];
extern int obsType[8];
extern uint8_t grounded;
extern double jumpVelo;
extern int randomNr;
extern int menu;
extern int gameOver;
extern int score;
extern int highscore;
extern int frameDino;
extern int pseudo0X[];
extern int pseudo0Y[];
extern int pseudo1X[];
extern int pseudo1Y[];
extern int pseudo2X[];
extern int pseudo2Y[];
extern int pseudo3X[];
extern int pseudo3Y[];
extern int pseudo4X[];
extern int pseudo4Y[];
extern int pseudo5X[];
extern int pseudo5Y[];
extern int pseudo6X[];
extern int pseudo6Y[];
extern int pseudo7X[];
extern int pseudo7Y[];
extern int pseudo8X[];
extern int pseudo8Y[];
extern int pseudo9X[];
extern int pseudo9Y[];
extern int* lettersX[];
extern int* lettersY[];
extern int lettersLength[];
