Dinosaur Game

Created by Brian Onoszko & Isack Ljungberg

Project created as a part of the Computer Hardware Engineering course at KTH.
Designed for usage on a ChipKIT UNO32 development board with a ChipKIT Basic I/O shield.

Based on the chrome offline screen game.

Requirements to run is the specified device and MCB32 toolchain for building the code onto the device

Controls:
	Btn 2 - Start/Restart
	Btn 3 - Duck/Fall
	Btn 4 - Jump

Reuse policy:
	Specified code bits and the stubs.c, vectors.S and makefile files were provided by the school.
	For copying refer to the Copying file. Other parts were written by us and are free to be reused.
